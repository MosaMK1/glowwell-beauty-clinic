/* GlowWell - site-wide behaviour */
(function () {
  'use strict';

  // Mobile navigation toggle
  var toggle = document.getElementById('navToggle');
  var nav = document.getElementById('mainNav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () { nav.classList.toggle('open'); });
  }

  // Success messages fade away after a few seconds (errors stay visible)
  var alerts = document.querySelectorAll('.alert-success');
  for (var i = 0; i < alerts.length; i++) {
    (function (el) {
      setTimeout(function () {
        el.style.transition = 'opacity .6s';
        el.style.opacity = '0';
        setTimeout(function () { el.parentNode && el.parentNode.removeChild(el); }, 650);
      }, 5000);
    })(alerts[i]);
  }
})();
