/* GlowWell - dynamic booking form.
   When the service or date changes, availability is fetched from the PHP JSON API
   (api/availability.php) and the free time slots are drawn without reloading the page. */
(function () {
  'use strict';
  var form = document.getElementById('bookForm');
  if (!form) return;
  var serviceSel = document.getElementById('service_id');
  var dateInp = document.getElementById('appt_date');
  var area = document.getElementById('slotArea');
  var staffInp = document.getElementById('staff_id');
  var timeInp = document.getElementById('start_time');
  var summary = document.getElementById('summary');
  var submitBtn = document.getElementById('submitBtn');
  var api = form.dataset.api || 'api/availability.php';
  var ignore = form.dataset.ignore || '0';
  // When editing, remember the current slot so it can be re-selected
  var keepStaff = form.dataset.staff || '0';
  var keepTime = form.dataset.time || '';

  function reset() {
    staffInp.value = ''; timeInp.value = ''; summary.hidden = true; submitBtn.disabled = true;
  }
  function msg(text, cls) {
    area.innerHTML = '';
    var p = document.createElement('p');
    p.className = cls || 'muted'; p.textContent = text;
    area.appendChild(p);
  }
  function choose(btn, staff, time) {
    area.querySelectorAll('.slot.selected').forEach(function (b) { b.classList.remove('selected'); });
    btn.classList.add('selected');
    staffInp.value = staff.staff_id; timeInp.value = time;
    summary.hidden = false;
    var svc = serviceSel.options[serviceSel.selectedIndex].text;
    summary.textContent = svc + ' with ' + staff.name + ' on ' + dateInp.value + ' at ' + time;
    submitBtn.disabled = false;
  }

  function load() {
    reset();
    if (!serviceSel.value || !dateInp.value) { msg('Select a service and a date to see available times.'); return; }
    msg('Checking availability...', 'loading');
    var url = api + '?service_id=' + encodeURIComponent(serviceSel.value) + '&date=' + encodeURIComponent(dateInp.value) + '&ignore=' + encodeURIComponent(ignore);
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url);
    xhr.onload = function () {
      var data;
      try { data = JSON.parse(xhr.responseText); } catch (e) { msg('Could not read the availability response.', 'alert alert-error'); return; }
      if (xhr.status !== 200) { msg(data.error || 'Something went wrong.', 'alert alert-error'); return; }
      render(data);
    };
    xhr.onerror = function () { msg('Network error - please try again.', 'alert alert-error'); };
    xhr.send();
  }

  function render(data) {
    area.innerHTML = '';
    var any = false;
    data.staff.forEach(function (s) {
      var row = document.createElement('div'); row.className = 'staff-row';
      var h = document.createElement('h4'); h.innerHTML = '';
      h.appendChild(document.createTextNode(s.name + ' '));
      var sp = document.createElement('span'); sp.textContent = '- ' + s.title; h.appendChild(sp);
      row.appendChild(h);
      var wrap = document.createElement('div'); wrap.className = 'slots';
      if (!s.slots.length) { var n = document.createElement('span'); n.className = 'muted'; n.textContent = 'No free slots on this day.'; wrap.appendChild(n); }
      s.slots.forEach(function (t) {
        any = true;
        var b = document.createElement('button'); b.type = 'button'; b.className = 'slot'; b.textContent = t;
        b.addEventListener('click', function () { choose(b, s, t); });
        if (String(s.staff_id) === keepStaff && t === keepTime) { setTimeout(function () { choose(b, s, t); }, 0); }
        wrap.appendChild(b);
      });
      row.appendChild(wrap); area.appendChild(row);
    });
    if (!any) { var warn = document.createElement('p'); warn.className = 'alert alert-error'; warn.textContent = 'Fully booked or closed on this date. Please try another day.'; area.insertBefore(warn, area.firstChild); }
  }

  serviceSel.addEventListener('change', function () { keepStaff = '0'; load(); });
  dateInp.addEventListener('change', function () { load(); });
  form.addEventListener('submit', function (ev) {
    if (!staffInp.value || !timeInp.value) { ev.preventDefault(); alert('Please pick a time slot first.'); }
  });
  if (serviceSel.value && dateInp.value) load();
})();
