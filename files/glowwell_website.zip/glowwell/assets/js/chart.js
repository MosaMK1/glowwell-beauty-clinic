/* GlowWell - lightweight bar chart drawn on a <canvas> (no external libraries).
   Data comes from the canvas attribute data-chart = [{label, value}, ...] */
(function () {
  'use strict';
  var canvas = document.getElementById('barChart');
  if (!canvas) return;
  var data = JSON.parse(canvas.getAttribute('data-chart') || '[]');
  var isMoney = canvas.getAttribute('data-money') === '1';
  var ctx = canvas.getContext('2d');
  var W = canvas.width, H = canvas.height, padL = 54, padB = 34, padT = 20, padR = 10;
  var progress = 0;

  function draw() {
    ctx.clearRect(0, 0, W, H);
    var max = 1;
    data.forEach(function (d) { if (d.value > max) max = d.value; });
    max = isMoney ? Math.ceil(max / 1000) * 1000 : Math.max(4, Math.ceil(max / 4) * 4);
    var plotW = W - padL - padR, plotH = H - padT - padB;
    ctx.font = '12px Segoe UI, Arial'; ctx.fillStyle = '#6f6578'; ctx.strokeStyle = '#eadfe4';
    for (var i = 0; i <= 4; i++) {            // grid lines + y labels
      var y = padT + plotH - (plotH * i / 4);
      ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(W - padR, y); ctx.stroke();
      ctx.textAlign = 'right';
      var v = max * i / 4; ctx.fillText(isMoney ? 'R' + Math.round(v) : Math.round(v * 10) / 10, padL - 8, y + 4);
    }
    var slot = plotW / Math.max(data.length, 1), bw = Math.min(slot * 0.55, 64);
    data.forEach(function (d, i) {
      var h = (d.value / max) * plotH * progress, x = padL + slot * i + (slot - bw) / 2, y = padT + plotH - h;
      var g = ctx.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, '#b5446e'); g.addColorStop(1, '#7a3a8a');
      ctx.fillStyle = g; ctx.fillRect(x, y, bw, h);
      ctx.fillStyle = '#2b2230'; ctx.textAlign = 'center';
      if (progress >= 1) ctx.fillText(isMoney ? 'R' + Math.round(d.value) : d.value, x + bw / 2, y - 5);
      ctx.fillStyle = '#6f6578'; ctx.fillText(d.label, x + bw / 2, H - 12);
    });
  }
  function animate() { progress += 0.08; if (progress > 1) progress = 1; draw(); if (progress < 1) requestAnimationFrame(animate); }
  animate();
})();
