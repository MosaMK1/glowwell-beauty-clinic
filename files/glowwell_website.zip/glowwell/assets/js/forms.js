/* GlowWell - form helpers: client-side validation, confirmations, auto-submit */
(function () {
  'use strict';

  // 1. Client-side validation for forms with class "js-validate"
  //    (the server validates again - this just gives instant feedback)
  var forms = document.querySelectorAll('form.js-validate');
  forms.forEach(function (form) {
    function showError(input, msg) {
      clearError(input);
      input.classList.add('invalid');
      var span = document.createElement('span');
      span.className = 'field-error';
      span.textContent = msg;
      input.parentNode.appendChild(span);
    }
    function clearError(input) {
      input.classList.remove('invalid');
      var old = input.parentNode.querySelector('.field-error');
      if (old) old.remove();
    }
    function check(input) {
      var v = input.value.trim();
      if (input.required && v === '') { showError(input, 'This field is required.'); return false; }
      if (input.type === 'email' && v !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) { showError(input, 'Enter a valid email address.'); return false; }
      if (input.pattern && v !== '' && !new RegExp('^(?:' + input.pattern + ')$').test(v)) { showError(input, input.dataset.msg || 'Invalid format.'); return false; }
      if (input.name === 'password' && input.minLength > 0 && v !== '' && (v.length < input.minLength || !/\d/.test(v))) { showError(input, 'Use at least 8 characters including a number.'); return false; }
      if (input.name === 'password2') {
        var p = form.querySelector('[name=password]');
        if (p && v !== p.value) { showError(input, 'Passwords do not match.'); return false; }
      }
      clearError(input);
      return true;
    }
    form.addEventListener('submit', function (ev) {
      var ok = true;
      form.querySelectorAll('input, select, textarea').forEach(function (inp) {
        if (inp.type !== 'hidden' && inp.type !== 'checkbox' && !check(inp)) ok = false;
      });
      if (!ok) { ev.preventDefault(); var first = form.querySelector('.invalid'); first && first.focus(); }
    });
    form.querySelectorAll('input, select').forEach(function (inp) {
      inp.addEventListener('blur', function () { if (inp.type !== 'hidden' && inp.type !== 'checkbox') check(inp); });
    });
  });

  // 2. Password strength meter on the register page
  var pw = document.getElementById('password');
  var bar = document.querySelector('#strength span');
  var txt = document.getElementById('strengthText');
  if (pw && bar) {
    pw.addEventListener('input', function () {
      var s = 0, v = pw.value;
      if (v.length >= 8) s++; if (/\d/.test(v)) s++; if (/[A-Z]/.test(v) && /[a-z]/.test(v)) s++; if (/[^A-Za-z0-9]/.test(v)) s++;
      var colours = ['#c0392b', '#e67e22', '#f1c40f', '#27ae60', '#1e8449'];
      var words = ['Very weak', 'Weak', 'Fair', 'Good', 'Strong'];
      bar.style.width = (s * 25) + '%';
      bar.style.background = colours[s];
      txt.textContent = v ? 'Strength: ' + words[s] : '';
    });
  }

  // 3. Confirm dialogs before destructive actions
  document.querySelectorAll('form.js-confirm').forEach(function (f) {
    f.addEventListener('submit', function (ev) {
      if (!window.confirm(f.dataset.confirm || 'Are you sure?')) ev.preventDefault();
    });
  });

  // 4. Status dropdowns submit immediately when changed
  document.querySelectorAll('form.js-autosubmit select').forEach(function (sel) {
    sel.addEventListener('change', function () { sel.form.submit(); });
  });

  // 5. Schedule editor: highlight the days that are switched on
  document.querySelectorAll('.work-toggle').forEach(function (cb) {
    cb.addEventListener('change', function () { cb.closest('.day').classList.toggle('on', cb.checked); });
  });
})();
