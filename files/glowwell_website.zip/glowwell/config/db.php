<?php
/**
 * Database connection (PDO). Edit the values below to match your MySQL server.
 * XAMPP/WAMP defaults: user "root" with an empty password.
 */
define('DB_HOST', getenv('GW_DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('GW_DB_NAME') ?: 'glowwell');
define('DB_USER', getenv('GW_DB_USER') ?: 'root');
define('DB_PASS', getenv('GW_DB_PASS') !== false ? getenv('GW_DB_PASS') : '');

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false, // real prepared statements
                ]
            );
        } catch (PDOException $ex) {
            http_response_code(500);
            die('Database connection failed. Please check config/db.php and that MySQL is running.');
        }
    }
    return $pdo;
}
