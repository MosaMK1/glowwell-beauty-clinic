<?php
$pageTitle = 'Welcome';
require 'includes/header.php';
$rows = db()->query(
    'SELECT c.name AS category, s.service_id, s.name, s.description, s.duration_min, s.price
     FROM services s JOIN service_categories c ON c.category_id = s.category_id
     WHERE s.is_active = 1 ORDER BY c.name, s.name'
)->fetchAll();
$grouped = [];
foreach ($rows as $r) {
    $grouped[$r['category']][] = $r;
}
?>
<section class="hero">
  <h1>Relax. Refresh. Glow.</h1>
  <p>Book facials, massages, hair treatments and more with GlowWell Beauty Clinic &ndash; in just a few clicks.</p>
  <a class="btn btn-large" href="book.php">Book an appointment</a>
</section>

<h2 class="section-title">Our Services</h2>
<?php foreach ($grouped as $cat => $list): ?>
  <h3 class="cat-title"><?= e($cat) ?></h3>
  <div class="card-grid">
    <?php foreach ($list as $s): ?>
      <div class="card">
        <h4><?= e($s['name']) ?></h4>
        <p class="muted"><?= e($s['description']) ?></p>
        <p class="meta"><span><?= (int)$s['duration_min'] ?> min</span> <strong><?= money($s['price']) ?></strong></p>
        <a class="btn btn-small" href="book.php?service=<?= (int)$s['service_id'] ?>">Book this</a>
      </div>
    <?php endforeach; ?>
  </div>
<?php endforeach; ?>
<?php require 'includes/footer.php'; ?>
