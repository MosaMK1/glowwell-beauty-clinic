<?php
$pageTitle = 'Book an appointment';
require_once 'includes/functions.php';
require_login();
if (is_admin()) {
    flash('error', 'Administrators create bookings from Admin > Bookings.');
    redirect('admin/bookings.php');
}
$cid = current_customer_id();
$pdo = db();
$errors = [];

// Reschedule mode: ?reschedule=ID loads an existing booking owned by this customer
$resId = (int)($_GET['reschedule'] ?? $_POST['reschedule'] ?? 0);
$existing = null;
if ($resId) {
    $st = $pdo->prepare("SELECT * FROM appointments WHERE appointment_id = ? AND customer_id = ? AND status IN ('pending','confirmed')");
    $st->execute([$resId, $cid]);
    $existing = $st->fetch();
    if (!$existing) {
        flash('error', 'That booking could not be found or can no longer be changed.');
        redirect('my_bookings.php');
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $serviceId = post('service_id');
    $staffId = post('staff_id');
    $date = post('appt_date');
    $time = post('start_time');
    $notes = post('notes');

    // --- Validation ---
    if (empty($serviceId) || !is_numeric($serviceId)) $errors[] = 'Please choose a service.';
    if (!valid_date($date)) $errors[] = 'Please choose a valid date.';
    elseif ($date < date('Y-m-d')) $errors[] = 'You cannot book a date in the past.';
    if (empty($staffId) || !is_numeric($staffId) || !valid_time($time)) $errors[] = 'Please pick an available time slot.';
    if (strlen($notes) > 255) $errors[] = 'Notes may not be longer than 255 characters.';

    if (!$errors) {
        $st = $pdo->prepare(
            'SELECT s.duration_min, s.price FROM services s
             JOIN staff_services ss ON ss.service_id = s.service_id
             WHERE s.service_id = ? AND ss.staff_id = ? AND s.is_active = 1'
        );
        $st->execute([(int)$serviceId, (int)$staffId]);
        $svc = $st->fetch();
        if (!$svc) {
            $errors[] = 'That staff member does not offer the selected service.';
        } else {
            $time = substr($time, 0, 5);
            $free = available_slots((int)$staffId, (int)$svc['duration_min'], $date, $resId);
            if (!in_array($time, $free, true)) {
                $errors[] = 'Sorry, that time slot has just been taken or is outside working hours. Please choose another.';
            } else {
                $end = add_minutes($time, (int)$svc['duration_min']);
                try {
                    if ($existing) {
                        $pdo->prepare("UPDATE appointments SET staff_id=?, service_id=?, appt_date=?, start_time=?, end_time=?, notes=?, status='pending', price_charged=? WHERE appointment_id=? AND customer_id=?")
                            ->execute([(int)$staffId, (int)$serviceId, $date, $time, $end, $notes ?: null, $svc['price'], $resId, $cid]);
                        notify($cid, $resId, 'Booking rescheduled', "Your appointment has been moved to $date at $time and is awaiting confirmation.");
                        flash('success', 'Your booking was rescheduled.');
                    } else {
                        $pdo->prepare('INSERT INTO appointments (customer_id,staff_id,service_id,appt_date,start_time,end_time,price_charged,notes) VALUES (?,?,?,?,?,?,?,?)')
                            ->execute([$cid, (int)$staffId, (int)$serviceId, $date, $time, $end, $svc['price'], $notes ?: null]);
                        notify($cid, (int)$pdo->lastInsertId(), 'Booking received', "Thank you! We have received your booking for $date at $time. You will be notified once it is confirmed.");
                        flash('success', 'Your booking was received. We will confirm it shortly.');
                    }
                    redirect('my_bookings.php');
                } catch (PDOException $ex) {
                    // The UNIQUE key uq_no_double_book is the final safety net
                    $errors[] = 'That slot was just booked by someone else. Please choose another time.';
                }
            }
        }
    }
}

$services = $pdo->query('SELECT s.service_id, s.name, s.duration_min, s.price, c.name AS cat FROM services s JOIN service_categories c ON c.category_id = s.category_id WHERE s.is_active = 1 ORDER BY c.name, s.name')->fetchAll();
$selService = (int)($_POST['service_id'] ?? ($existing['service_id'] ?? ($_GET['service'] ?? 0)));
$selDate = $_POST['appt_date'] ?? ($existing['appt_date'] ?? '');
$notesVal = $_POST['notes'] ?? ($existing['notes'] ?? '');

require 'includes/header.php';
?>
<h2><?= $existing ? 'Reschedule booking #' . (int)$resId : 'Book an appointment' ?></h2>
<?php foreach ($errors as $er): ?><div class="alert alert-error"><?= e($er) ?></div><?php endforeach; ?>

<form method="post" id="bookForm" class="panel" data-ignore="<?= (int)$resId ?>" data-staff="<?= (int)($existing["staff_id"] ?? 0) ?>" data-time="<?= e(substr($existing["start_time"] ?? "", 0, 5)) ?>">
  <?= csrf_field() ?>
  <input type="hidden" name="reschedule" value="<?= (int)$resId ?>">
  <input type="hidden" name="staff_id" id="staff_id">
  <input type="hidden" name="start_time" id="start_time">
  <div class="grid-2">
    <label>1. Choose a service
      <select name="service_id" id="service_id" required>
        <option value="">-- Select a service --</option>
        <?php $lastCat = ''; foreach ($services as $s):
            if ($s['cat'] !== $lastCat) { if ($lastCat !== '') echo '</optgroup>'; echo '<optgroup label="' . e($s['cat']) . '">'; $lastCat = $s['cat']; } ?>
          <option value="<?= (int)$s['service_id'] ?>" <?= $selService === (int)$s['service_id'] ? 'selected' : '' ?>>
            <?= e($s['name']) ?> (<?= (int)$s['duration_min'] ?> min, <?= money($s['price']) ?>)
          </option>
        <?php endforeach; ?></optgroup>
      </select>
    </label>
    <label>2. Choose a date
      <input type="date" name="appt_date" id="appt_date" min="<?= date('Y-m-d') ?>" value="<?= e($selDate) ?>" required>
    </label>
  </div>

  <label class="block-label">3. Pick a therapist and time</label>
  <div id="slotArea" class="slot-area"><p class="muted">Select a service and a date to see available times.</p></div>
  <div id="summary" class="summary" hidden></div>

  <label>Notes for the therapist (optional)
    <textarea name="notes" id="notes" rows="2" maxlength="255"><?= e($notesVal) ?></textarea>
  </label>
  <button class="btn" type="submit" id="submitBtn" disabled><?= $existing ? 'Save new time' : 'Confirm booking' ?></button>
  <a class="btn btn-outline" href="my_bookings.php">Cancel</a>
</form>
<?php $extraJs = 'booking.js'; require 'includes/footer.php'; ?>
