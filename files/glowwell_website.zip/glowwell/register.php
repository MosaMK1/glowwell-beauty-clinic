<?php
$pageTitle = 'Register';
require_once 'includes/functions.php';
$errors = [];
$old = ['full_name' => '', 'email' => '', 'phone' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $old = ['full_name' => post('full_name'), 'email' => post('email'), 'phone' => post('phone')];
    $pass = $_POST['password'] ?? '';
    $pass2 = $_POST['password2'] ?? '';

    // --- Validation ---
    if (empty($old['full_name']) || strlen($old['full_name']) < 3) $errors[] = 'Please enter your full name (at least 3 characters).';
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Please enter a valid email address.';
    if (!valid_phone($old['phone'])) $errors[] = 'Phone number must be 10 digits starting with 0 (e.g. 0821234567).';
    if (strlen($pass) < 8 || !preg_match('/\d/', $pass)) $errors[] = 'Password must be at least 8 characters and include a number.';
    if ($pass !== $pass2) $errors[] = 'The two passwords do not match.';

    if (!$errors) {
        $pdo = db();
        $st = $pdo->prepare('SELECT 1 FROM users WHERE email = ? UNION SELECT 1 FROM customers WHERE email = ?');
        $st->execute([$old['email'], $old['email']]);
        if ($st->fetch()) {
            $errors[] = 'An account with that email address already exists. Try logging in instead.';
        } else {
            try {
                $pdo->beginTransaction();
                $pdo->prepare('INSERT INTO users (full_name,email,password_hash,role) VALUES (?,?,?,?)')
                    ->execute([$old['full_name'], $old['email'], password_hash($pass, PASSWORD_DEFAULT), 'customer']);
                $uid = (int)$pdo->lastInsertId();
                $pdo->prepare('INSERT INTO customers (user_id,full_name,email,phone) VALUES (?,?,?,?)')
                    ->execute([$uid, $old['full_name'], $old['email'], $old['phone']]);
                $pdo->commit();
                flash('success', 'Account created! You can now log in.');
                redirect('login.php');
            } catch (PDOException $ex) {
                $pdo->rollBack();
                $errors[] = 'Sorry, we could not create your account. Please try again.';
            }
        }
    }
}
require 'includes/header.php';
?>
<div class="form-box">
  <h2>Create your account</h2>
  <?php foreach ($errors as $er): ?><div class="alert alert-error"><?= e($er) ?></div><?php endforeach; ?>
  <form method="post" class="js-validate" novalidate>
    <?= csrf_field() ?>
    <label>Full name<input type="text" name="full_name" value="<?= e($old['full_name']) ?>" required></label>
    <label>Email<input type="email" name="email" value="<?= e($old['email']) ?>" required></label>
    <label>Phone (10 digits)<input type="text" name="phone" value="<?= e($old['phone']) ?>" required pattern="0\d{9}" data-msg="Phone must be 10 digits starting with 0"></label>
    <label>Password<input type="password" name="password" id="password" required minlength="8"></label>
    <div class="strength" id="strength"><span></span></div><small id="strengthText" class="muted"></small>
    <label>Confirm password<input type="password" name="password2" required></label>
    <button class="btn btn-block" type="submit">Register</button>
  </form>
  <p class="muted center">Already registered? <a href="login.php">Log in</a></p>
</div>
<?php $extraJs = 'forms.js'; require 'includes/footer.php'; ?>
