GlowWell Beauty Clinic Management System
HSYD300-1 Systems Development 3 - Summative Assessment 1

SETUP (XAMPP / WAMP)
1. Start Apache and MySQL.
2. Copy this "glowwell" folder into htdocs (XAMPP) or www (WAMP).
3. In phpMyAdmin choose Import and run database/glowwell.sql
   (creates the "glowwell" database, tables and sample data).
4. If your MySQL login is not root / empty password, edit config/db.php.
5. Browse to http://localhost/glowwell/

LOGINS
Admin:    admin@glowwell.co.za / Admin@123
Customer: thandi@example.com   / Customer@123

FOLDERS
config/    database connection (PDO)
includes/  shared header, footer and helper functions
admin/     administrator pages (dashboard, bookings, customers, staff, schedules, services, reports)
api/       JSON availability endpoint used by JavaScript
assets/    CSS and JavaScript
database/  glowwell.sql (schema + sample data)
