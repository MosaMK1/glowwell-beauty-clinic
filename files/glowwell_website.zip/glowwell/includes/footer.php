</main>
<footer class="site-footer">
  <div class="container">&copy; <?= date('Y') ?> GlowWell Beauty Clinic &middot; Mon&ndash;Fri 09:00&ndash;17:00 &middot; Sat 09:00&ndash;13:00</div>
</footer>
<script src="<?= base_url() ?>/assets/js/app.js"></script>
<?php if (!empty($extraJs)) echo '<script src="' . base_url() . '/assets/js/' . e($extraJs) . '"></script>'; ?>
</body>
</html>
