<?php
/**
 * Shared helper functions: sessions, security, validation, booking logic.
 */
require_once __DIR__ . '/../config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* ---------- Output / navigation helpers ---------- */

// Escape output to prevent XSS
function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function base_url(): string
{
    // Works whether the project sits in /glowwell/ or the web root
    $dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
    if (basename($dir) === 'admin' || basename($dir) === 'api') {
        $dir = dirname($dir);
    }
    return rtrim($dir, '/');
}

function money($amount): string
{
    return 'R ' . number_format((float)$amount, 2);
}

/* ---------- Flash messages (user feedback) ---------- */

function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $message];
}

function show_flash(): void
{
    foreach ($_SESSION['flash'] ?? [] as $f) {
        echo '<div class="alert alert-' . e($f['type']) . '">' . e($f['msg']) . '</div>';
    }
    unset($_SESSION['flash']);
}

/* ---------- CSRF protection ---------- */

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

// Stops the request if the token is missing or wrong
function csrf_check(): void
{
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(400);
        die('Invalid or expired form. Please go back, refresh the page and try again.');
    }
}

/* ---------- Authentication / authorisation ---------- */

function is_logged_in(): bool
{
    return isset($_SESSION['user']);
}

function is_admin(): bool
{
    return is_logged_in() && $_SESSION['user']['role'] === 'admin';
}

function require_login(): void
{
    if (!is_logged_in()) {
        flash('error', 'Please log in to continue.');
        redirect(base_url() . '/login.php');
    }
}

function require_admin(): void
{
    require_login();
    if (!is_admin()) {
        flash('error', 'You do not have permission to view that page.');
        redirect(base_url() . '/index.php');
    }
}

// Returns the customer_id linked to the logged-in user
function current_customer_id(): ?int
{
    if (!is_logged_in()) {
        return null;
    }
    $st = db()->prepare('SELECT customer_id FROM customers WHERE user_id = ?');
    $st->execute([$_SESSION['user']['user_id']]);
    $id = $st->fetchColumn();
    return $id ? (int)$id : null;
}

/* ---------- Validation helpers ---------- */

function post(string $key): string
{
    return trim((string)($_POST[$key] ?? ''));
}

function valid_date(string $d): bool
{
    $dt = DateTime::createFromFormat('Y-m-d', $d);
    return $dt && $dt->format('Y-m-d') === $d;
}

function valid_time(string $t): bool
{
    return (bool)preg_match('/^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/', $t);
}

// South African style phone number: 10 digits starting with 0
function valid_phone(string $p): bool
{
    return (bool)preg_match('/^0\d{9}$/', $p);
}

/* ---------- Booking logic ---------- */

function add_minutes(string $time, int $min): string
{
    return date('H:i:s', strtotime($time) + $min * 60);
}

/**
 * Returns the free start times (HH:MM) for one staff member, service and date.
 * Slots are every 30 minutes inside the staff member's working hours and
 * must not overlap any non-cancelled appointment.
 * $ignoreAppt lets a booking being rescheduled ignore itself.
 */
function available_slots(int $staffId, int $duration, string $date, int $ignoreAppt = 0): array
{
    $pdo = db();
    $dow = (int)date('N', strtotime($date));
    $st = $pdo->prepare('SELECT start_time, end_time FROM staff_schedules WHERE staff_id = ? AND day_of_week = ?');
    $st->execute([$staffId, $dow]);
    $sch = $st->fetch();
    if (!$sch) {
        return []; // not working that day
    }

    $st = $pdo->prepare(
        "SELECT start_time, end_time FROM appointments
         WHERE staff_id = ? AND appt_date = ? AND status <> 'cancelled' AND appointment_id <> ?"
    );
    $st->execute([$staffId, $date, $ignoreAppt]);
    $busy = $st->fetchAll();

    $slots = [];
    $t = strtotime($sch['start_time']);
    $close = strtotime($sch['end_time']);
    $isToday = ($date === date('Y-m-d'));
    for (; $t + $duration * 60 <= $close; $t += 30 * 60) {
        $start = date('H:i:s', $t);
        $end = date('H:i:s', $t + $duration * 60);
        if ($isToday && $t <= time()) {
            continue; // already passed
        }
        $clash = false;
        foreach ($busy as $b) {
            if ($start < $b['end_time'] && $end > $b['start_time']) {
                $clash = true;
                break;
            }
        }
        if (!$clash) {
            $slots[] = substr($start, 0, 5);
        }
    }
    return $slots;
}

// Records an "email" in the notifications table and attempts PHP mail()
function notify(int $customerId, ?int $apptId, string $subject, string $message): void
{
    $pdo = db();
    $pdo->prepare('INSERT INTO notifications (customer_id, appointment_id, subject, message) VALUES (?,?,?,?)')
        ->execute([$customerId, $apptId, $subject, $message]);
    $st = $pdo->prepare('SELECT email FROM customers WHERE customer_id = ?');
    $st->execute([$customerId]);
    if ($to = $st->fetchColumn()) {
        @mail($to, $subject, $message, 'From: bookings@glowwell.co.za'); // silently ignored if no mail server
    }
}
