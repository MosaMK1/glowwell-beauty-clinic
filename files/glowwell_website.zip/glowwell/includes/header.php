<?php
require_once __DIR__ . '/functions.php';
$base = base_url();
$page = basename($_SERVER['SCRIPT_NAME']);
$inAdmin = basename(dirname($_SERVER['SCRIPT_NAME'])) === 'admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle ?? 'GlowWell Beauty Clinic') ?> | GlowWell</title>
<link rel="stylesheet" href="<?= $base ?>/assets/css/style.css">
</head>
<body>
<header class="site-header">
  <div class="container nav-wrap">
    <a class="brand" href="<?= $base ?>/index.php"><span class="brand-mark">&#10048;</span> GlowWell</a>
    <button class="nav-toggle" id="navToggle" aria-label="Toggle menu">&#9776;</button>
    <nav id="mainNav">
      <?php if (is_admin()): ?>
        <a href="<?= $base ?>/admin/dashboard.php" class="<?= $page === 'dashboard.php' ? 'active' : '' ?>">Dashboard</a>
        <a href="<?= $base ?>/admin/bookings.php" class="<?= $page === 'bookings.php' ? 'active' : '' ?>">Bookings</a>
        <a href="<?= $base ?>/admin/customers.php" class="<?= $page === 'customers.php' ? 'active' : '' ?>">Customers</a>
        <a href="<?= $base ?>/admin/staff.php" class="<?= $page === 'staff.php' ? 'active' : '' ?>">Staff</a>
        <a href="<?= $base ?>/admin/schedules.php" class="<?= $page === 'schedules.php' ? 'active' : '' ?>">Schedules</a>
        <a href="<?= $base ?>/admin/services.php" class="<?= $page === 'services.php' ? 'active' : '' ?>">Services</a>
        <a href="<?= $base ?>/admin/reports.php" class="<?= $page === 'reports.php' ? 'active' : '' ?>">Reports</a>
      <?php else: ?>
        <a href="<?= $base ?>/index.php" class="<?= $page === 'index.php' ? 'active' : '' ?>">Home</a>
        <a href="<?= $base ?>/book.php" class="<?= $page === 'book.php' ? 'active' : '' ?>">Book Now</a>
        <?php if (is_logged_in()): ?>
          <a href="<?= $base ?>/my_bookings.php" class="<?= $page === 'my_bookings.php' ? 'active' : '' ?>">My Bookings</a>
        <?php endif; ?>
      <?php endif; ?>
      <?php if (is_logged_in()): ?>
        <a class="btn btn-small btn-outline" href="<?= $base ?>/logout.php">Logout (<?= e(explode(' ', $_SESSION['user']['full_name'])[0]) ?>)</a>
      <?php else: ?>
        <a href="<?= $base ?>/login.php" class="<?= $page === 'login.php' ? 'active' : '' ?>">Login</a>
        <a class="btn btn-small" href="<?= $base ?>/register.php">Register</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main class="container">
<?php show_flash(); ?>
