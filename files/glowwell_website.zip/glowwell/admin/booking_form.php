<?php
$pageTitle = 'Booking form';
require_once '../includes/functions.php';
require_admin();
$pdo = db();
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$existing = null;
if ($id) {
    $st = $pdo->prepare('SELECT * FROM appointments WHERE appointment_id = ?');
    $st->execute([$id]);
    $existing = $st->fetch();
    if (!$existing) { flash('error', 'Booking not found.'); redirect('bookings.php'); }
}
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $customerId = post('customer_id'); $serviceId = post('service_id'); $staffId = post('staff_id');
    $date = post('appt_date'); $time = post('start_time'); $status = post('status'); $notes = post('notes');

    if (empty($customerId) || !is_numeric($customerId)) $errors[] = 'Please select a customer.';
    if (empty($serviceId) || !is_numeric($serviceId)) $errors[] = 'Please select a service.';
    if (!valid_date($date)) $errors[] = 'Please choose a valid date.';
    if (empty($staffId) || !is_numeric($staffId) || !valid_time($time)) $errors[] = 'Please pick an available time slot.';
    if (!in_array($status, ['pending', 'confirmed', 'completed', 'cancelled'], true)) $errors[] = 'Invalid status.';

    if (!$errors) {
        $st = $pdo->prepare('SELECT s.duration_min, s.price FROM services s JOIN staff_services ss ON ss.service_id=s.service_id WHERE s.service_id=? AND ss.staff_id=?');
        $st->execute([(int)$serviceId, (int)$staffId]);
        $svc = $st->fetch();
        $st = $pdo->prepare('SELECT 1 FROM customers WHERE customer_id = ?');
        $st->execute([(int)$customerId]);
        if (!$svc) $errors[] = 'That staff member does not offer the selected service.';
        elseif (!$st->fetch()) $errors[] = 'The selected customer does not exist.';
        else {
            $time = substr($time, 0, 5);
            if (!in_array($time, available_slots((int)$staffId, (int)$svc['duration_min'], $date, $id), true)) {
                $errors[] = 'That slot is not available (double booking or outside working hours).';
            } else {
                $end = add_minutes($time, (int)$svc['duration_min']);
                try {
                    if ($id) {
                        $pdo->prepare('UPDATE appointments SET customer_id=?, staff_id=?, service_id=?, appt_date=?, start_time=?, end_time=?, status=?, notes=? WHERE appointment_id=?')
                            ->execute([(int)$customerId, (int)$staffId, (int)$serviceId, $date, $time, $end, $status, $notes ?: null, $id]);
                        flash('success', 'Booking updated.');
                    } else {
                        $pdo->prepare('INSERT INTO appointments (customer_id,staff_id,service_id,appt_date,start_time,end_time,status,price_charged,notes) VALUES (?,?,?,?,?,?,?,?,?)')
                            ->execute([(int)$customerId, (int)$staffId, (int)$serviceId, $date, $time, $end, $status, $svc['price'], $notes ?: null]);
                        notify((int)$customerId, (int)$pdo->lastInsertId(), 'Booking created', "A booking was made for you on $date at $time.");
                        flash('success', 'Booking created and the customer was notified.');
                    }
                    redirect('bookings.php');
                } catch (PDOException $ex) {
                    $errors[] = 'That slot was just taken. Please choose another time.';
                }
            }
        }
    }
}
$customers = $pdo->query('SELECT customer_id, full_name, email FROM customers ORDER BY full_name')->fetchAll();
$services = $pdo->query('SELECT service_id, name, duration_min FROM services WHERE is_active=1 ORDER BY name')->fetchAll();
$v = fn($k, $d = '') => $_POST[$k] ?? ($existing[$k] ?? $d);
require '../includes/header.php';
?>
<h2><?= $id ? 'Edit booking #' . $id : 'New booking' ?></h2>
<?php foreach ($errors as $er): ?><div class="alert alert-error"><?= e($er) ?></div><?php endforeach; ?>
<form method="post" id="bookForm" class="panel" data-ignore="<?= $id ?>" data-staff="<?= (int)($existing["staff_id"] ?? 0) ?>" data-time="<?= e(substr($existing["start_time"] ?? "", 0, 5)) ?>" data-api="../api/availability.php">
  <?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>">
  <input type="hidden" name="staff_id" id="staff_id"><input type="hidden" name="start_time" id="start_time">
  <div class="grid-2">
    <label>Customer
      <select name="customer_id" required><option value="">-- Select customer --</option>
        <?php foreach ($customers as $c): ?><option value="<?= (int)$c['customer_id'] ?>" <?= (int)$v('customer_id') === (int)$c['customer_id'] ? 'selected' : '' ?>><?= e($c['full_name']) ?> (<?= e($c['email']) ?>)</option><?php endforeach; ?>
      </select></label>
    <label>Status
      <select name="status"><?php foreach (['confirmed', 'pending', 'completed', 'cancelled'] as $s): ?><option value="<?= $s ?>" <?= $v('status', 'confirmed') === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option><?php endforeach; ?></select></label>
    <label>Service
      <select name="service_id" id="service_id" required><option value="">-- Select service --</option>
        <?php foreach ($services as $s): ?><option value="<?= (int)$s['service_id'] ?>" <?= (int)$v('service_id') === (int)$s['service_id'] ? 'selected' : '' ?>><?= e($s['name']) ?> (<?= (int)$s['duration_min'] ?> min)</option><?php endforeach; ?>
      </select></label>
    <label>Date<input type="date" name="appt_date" id="appt_date" value="<?= e($v('appt_date')) ?>" required></label>
  </div>
  <label class="block-label">Therapist and time</label>
  <div id="slotArea" class="slot-area"><p class="muted">Select a service and a date to see available times.</p></div>
  <div id="summary" class="summary" hidden></div>
  <label>Notes<textarea name="notes" id="notes" rows="2" maxlength="255"><?= e($v('notes')) ?></textarea></label>
  <button class="btn" type="submit" id="submitBtn" disabled><?= $id ? 'Save changes' : 'Create booking' ?></button>
  <a class="btn btn-outline" href="bookings.php">Cancel</a>
</form>
<?php $extraJs = 'booking.js'; require '../includes/footer.php'; ?>
