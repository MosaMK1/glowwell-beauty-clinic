<?php
$pageTitle = 'Admin dashboard';
require_once '../includes/functions.php';
require_admin();
$pdo = db();
$today = date('Y-m-d');

$stats = [
    'Today\'s bookings'   => $pdo->query("SELECT COUNT(*) FROM appointments WHERE appt_date = CURDATE() AND status <> 'cancelled'")->fetchColumn(),
    'Pending approval'    => $pdo->query("SELECT COUNT(*) FROM appointments WHERE status = 'pending'")->fetchColumn(),
    'Registered customers'=> $pdo->query('SELECT COUNT(*) FROM customers')->fetchColumn(),
    'Active staff'        => $pdo->query('SELECT COUNT(*) FROM staff WHERE is_active = 1')->fetchColumn(),
];
$revenue = $pdo->query("SELECT COALESCE(SUM(price_charged),0) FROM appointments WHERE status IN ('confirmed','completed') AND YEAR(appt_date)=YEAR(CURDATE()) AND MONTH(appt_date)=MONTH(CURDATE())")->fetchColumn();

$upcoming = $pdo->query(
    "SELECT a.*, c.full_name AS customer, s.name AS service, st.full_name AS therapist
     FROM appointments a JOIN customers c ON c.customer_id=a.customer_id
     JOIN services s ON s.service_id=a.service_id JOIN staff st ON st.staff_id=a.staff_id
     WHERE a.appt_date >= CURDATE() AND a.status IN ('pending','confirmed')
     ORDER BY a.appt_date, a.start_time LIMIT 8"
)->fetchAll();

// Bookings per day for the next 7 days (feeds the JavaScript chart)
$chart = [];
for ($i = 0; $i < 7; $i++) {
    $d = date('Y-m-d', strtotime("+$i day"));
    $st = $pdo->prepare("SELECT COUNT(*) FROM appointments WHERE appt_date = ? AND status <> 'cancelled'");
    $st->execute([$d]);
    $chart[] = ['label' => date('D d', strtotime($d)), 'value' => (int)$st->fetchColumn()];
}
require '../includes/header.php';
?>
<div class="page-head"><h2>Dashboard</h2><span class="muted"><?= e(date('l, d F Y')) ?></span></div>
<div class="stat-grid">
  <?php foreach ($stats as $label => $val): ?>
    <div class="stat"><div class="stat-num" data-count="<?= (int)$val ?>"><?= (int)$val ?></div><div class="muted"><?= e($label) ?></div></div>
  <?php endforeach; ?>
  <div class="stat stat-accent"><div class="stat-num"><?= money($revenue) ?></div><div>Revenue this month</div></div>
</div>

<div class="grid-2 top">
  <div class="panel">
    <h3>Bookings &ndash; next 7 days</h3>
    <canvas id="barChart" width="520" height="260" data-chart='<?= e(json_encode($chart)) ?>'></canvas>
  </div>
  <div class="panel">
    <h3>Quick actions</h3>
    <div class="quick">
      <a class="btn" href="booking_form.php">+ New booking</a>
      <a class="btn btn-outline" href="customers.php?add=1">+ New customer</a>
      <a class="btn btn-outline" href="bookings.php?status=pending">Review pending</a>
      <a class="btn btn-outline" href="reports.php">View reports</a>
    </div>
  </div>
</div>

<h3>Upcoming appointments</h3>
<div class="table-wrap"><table class="table">
  <thead><tr><th>Date</th><th>Time</th><th>Customer</th><th>Service</th><th>Therapist</th><th>Status</th></tr></thead>
  <tbody>
  <?php foreach ($upcoming as $r): ?>
    <tr>
      <td><?= e(date('D d M', strtotime($r['appt_date']))) ?></td>
      <td><?= e(substr($r['start_time'], 0, 5)) ?></td>
      <td><?= e($r['customer']) ?></td><td><?= e($r['service']) ?></td><td><?= e($r['therapist']) ?></td>
      <td><span class="badge badge-<?= e($r['status']) ?>"><?= e(ucfirst($r['status'])) ?></span></td>
    </tr>
  <?php endforeach; if (!$upcoming): ?><tr><td colspan="6" class="center muted">No upcoming appointments.</td></tr><?php endif; ?>
  </tbody>
</table></div>
<?php $extraJs = 'chart.js'; require '../includes/footer.php'; ?>
