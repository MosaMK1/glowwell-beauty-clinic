<?php
$pageTitle = 'Manage bookings';
require_once '../includes/functions.php';
require_admin();
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = post('appointment_id');
    $action = post('action');
    if (empty($id) || !is_numeric($id)) {
        flash('error', 'Invalid booking selected.');
    } elseif ($action === 'delete') {
        $st = $pdo->prepare('DELETE FROM appointments WHERE appointment_id = ?');
        $st->execute([(int)$id]);
        flash($st->rowCount() ? 'success' : 'error', $st->rowCount() ? 'Booking deleted.' : 'Booking not found.');
    } elseif ($action === 'status' && in_array(post('status'), ['pending', 'confirmed', 'completed', 'cancelled'], true)) {
        $pdo->prepare('UPDATE appointments SET status = ? WHERE appointment_id = ?')->execute([post('status'), (int)$id]);
        $st = $pdo->prepare('SELECT customer_id, appt_date, start_time FROM appointments WHERE appointment_id = ?');
        $st->execute([(int)$id]);
        if ($a = $st->fetch()) {
            notify((int)$a['customer_id'], (int)$id, 'Booking ' . post('status'), "Your booking for {$a['appt_date']} at " . substr($a['start_time'], 0, 5) . ' is now ' . post('status') . '.');
        }
        flash('success', 'Status updated and the customer was notified.');
    }
    redirect('bookings.php?' . http_build_query(array_filter(['status' => $_GET['status'] ?? '', 'q' => $_GET['q'] ?? '', 'from' => $_GET['from'] ?? '', 'to' => $_GET['to'] ?? ''])));
}

// Filters (all passed to the query as bound parameters)
$status = $_GET['status'] ?? '';
$q = trim($_GET['q'] ?? '');
$from = $_GET['from'] ?? '';
$to = $_GET['to'] ?? '';
$where = ['1=1'];
$params = [];
if (in_array($status, ['pending', 'confirmed', 'completed', 'cancelled'], true)) { $where[] = 'a.status = ?'; $params[] = $status; }
if ($q !== '') { $where[] = '(c.full_name LIKE ? OR s.name LIKE ? OR st.full_name LIKE ?)'; array_push($params, "%$q%", "%$q%", "%$q%"); }
if (valid_date($from)) { $where[] = 'a.appt_date >= ?'; $params[] = $from; }
if (valid_date($to)) { $where[] = 'a.appt_date <= ?'; $params[] = $to; }

$st = $pdo->prepare(
    'SELECT a.*, c.full_name AS customer, s.name AS service, st.full_name AS therapist
     FROM appointments a JOIN customers c ON c.customer_id=a.customer_id
     JOIN services s ON s.service_id=a.service_id JOIN staff st ON st.staff_id=a.staff_id
     WHERE ' . implode(' AND ', $where) . ' ORDER BY a.appt_date DESC, a.start_time DESC'
);
$st->execute($params);
$rows = $st->fetchAll();
require '../includes/header.php';
?>
<div class="page-head"><h2>Bookings</h2><a class="btn" href="booking_form.php">+ New booking</a></div>
<form method="get" class="filters panel">
  <input type="text" name="q" placeholder="Search customer, service or therapist" value="<?= e($q) ?>">
  <select name="status"><option value="">All statuses</option>
    <?php foreach (['pending', 'confirmed', 'completed', 'cancelled'] as $s): ?>
      <option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
    <?php endforeach; ?></select>
  <input type="date" name="from" value="<?= e($from) ?>" title="From date">
  <input type="date" name="to" value="<?= e($to) ?>" title="To date">
  <button class="btn" type="submit">Filter</button><a class="btn btn-outline" href="bookings.php">Reset</a>
</form>
<p class="muted"><?= count($rows) ?> booking(s) found</p>
<div class="table-wrap"><table class="table">
  <thead><tr><th>#</th><th>Date</th><th>Time</th><th>Customer</th><th>Service</th><th>Therapist</th><th>Price</th><th>Status</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= (int)$r['appointment_id'] ?></td>
      <td><?= e(date('d M Y', strtotime($r['appt_date']))) ?></td>
      <td><?= e(substr($r['start_time'], 0, 5)) ?>&ndash;<?= e(substr($r['end_time'], 0, 5)) ?></td>
      <td><?= e($r['customer']) ?></td><td><?= e($r['service']) ?></td><td><?= e($r['therapist']) ?></td>
      <td><?= money($r['price_charged']) ?></td>
      <td>
        <form method="post" class="inline js-autosubmit">
          <?= csrf_field() ?><input type="hidden" name="action" value="status">
          <input type="hidden" name="appointment_id" value="<?= (int)$r['appointment_id'] ?>">
          <select name="status" class="status-select badge-<?= e($r['status']) ?>">
            <?php foreach (['pending', 'confirmed', 'completed', 'cancelled'] as $s): ?>
              <option value="<?= $s ?>" <?= $r['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
            <?php endforeach; ?></select>
        </form>
      </td>
      <td class="actions">
        <a class="btn btn-small btn-outline" href="booking_form.php?id=<?= (int)$r['appointment_id'] ?>">Edit</a>
        <form method="post" class="inline js-confirm" data-confirm="Permanently delete booking #<?= (int)$r['appointment_id'] ?>?">
          <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="appointment_id" value="<?= (int)$r['appointment_id'] ?>">
          <button class="btn btn-small btn-danger" type="submit">Delete</button>
        </form>
      </td>
    </tr>
  <?php endforeach; if (!$rows): ?><tr><td colspan="9" class="center muted">No bookings match your filters.</td></tr><?php endif; ?>
  </tbody>
</table></div>
<?php $extraJs = 'forms.js'; require '../includes/footer.php'; ?>
