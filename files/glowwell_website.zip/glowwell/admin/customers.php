<?php
$pageTitle = 'Customers';
require_once '../includes/functions.php';
require_admin();
$pdo = db();
$errors = [];
$editId = (int)($_GET['edit'] ?? $_POST['customer_id'] ?? 0);
$showForm = isset($_GET['add']) || $editId;
$row = ['full_name' => '', 'email' => '', 'phone' => '', 'notes' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (post('action') === 'delete') {
        $st = $pdo->prepare('DELETE FROM customers WHERE customer_id = ?');
        $st->execute([(int)post('customer_id')]);
        flash($st->rowCount() ? 'success' : 'error', $st->rowCount() ? 'Customer and their bookings were deleted.' : 'Customer not found.');
        redirect('customers.php');
    }
    // Create / update
    $row = ['full_name' => post('full_name'), 'email' => post('email'), 'phone' => post('phone'), 'notes' => post('notes')];
    if (empty($row['full_name'])) $errors[] = 'Full name is required.';
    if (!filter_var($row['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'A valid email address is required.';
    if (!valid_phone($row['phone'])) $errors[] = 'Phone must be 10 digits starting with 0.';
    if (strlen($row['notes']) > 255) $errors[] = 'Notes are too long (max 255 characters).';
    if (!$errors) {
        $st = $pdo->prepare('SELECT 1 FROM customers WHERE email = ? AND customer_id <> ?');
        $st->execute([$row['email'], $editId]);
        if ($st->fetch()) $errors[] = 'Another customer already uses that email address.';
    }
    if (!$errors) {
        if ($editId) {
            $pdo->prepare('UPDATE customers SET full_name=?, email=?, phone=?, notes=? WHERE customer_id=?')
                ->execute([$row['full_name'], $row['email'], $row['phone'], $row['notes'] ?: null, $editId]);
            flash('success', 'Customer updated.');
        } else {
            $pdo->prepare('INSERT INTO customers (full_name,email,phone,notes) VALUES (?,?,?,?)')
                ->execute([$row['full_name'], $row['email'], $row['phone'], $row['notes'] ?: null]);
            flash('success', 'Customer added.');
        }
        redirect('customers.php');
    }
    $showForm = true;
} elseif ($editId) {
    $st = $pdo->prepare('SELECT * FROM customers WHERE customer_id = ?');
    $st->execute([$editId]);
    $row = $st->fetch();
    if (!$row) { flash('error', 'Customer not found.'); redirect('customers.php'); }
}

$q = trim($_GET['q'] ?? '');
$st = $pdo->prepare(
    "SELECT c.*, COUNT(a.appointment_id) AS visits, COALESCE(SUM(CASE WHEN a.status IN ('confirmed','completed') THEN a.price_charged END),0) AS spent
     FROM customers c LEFT JOIN appointments a ON a.customer_id = c.customer_id
     WHERE c.full_name LIKE ? OR c.email LIKE ? OR c.phone LIKE ?
     GROUP BY c.customer_id ORDER BY c.full_name"
);
$st->execute(["%$q%", "%$q%", "%$q%"]);
$rows = $st->fetchAll();
require '../includes/header.php';
?>
<div class="page-head"><h2>Customers</h2><a class="btn" href="customers.php?add=1">+ Add customer</a></div>
<?php if ($showForm): ?>
<form method="post" class="panel js-validate" novalidate>
  <h3><?= $editId ? 'Edit customer' : 'Add customer' ?></h3>
  <?php foreach ($errors as $er): ?><div class="alert alert-error"><?= e($er) ?></div><?php endforeach; ?>
  <?= csrf_field() ?><input type="hidden" name="customer_id" value="<?= $editId ?>">
  <div class="grid-2">
    <label>Full name<input type="text" name="full_name" value="<?= e($row['full_name']) ?>" required></label>
    <label>Email<input type="email" name="email" value="<?= e($row['email']) ?>" required></label>
    <label>Phone<input type="text" name="phone" value="<?= e($row['phone']) ?>" required pattern="0\d{9}" data-msg="Phone must be 10 digits starting with 0"></label>
    <label>Notes<input type="text" name="notes" value="<?= e($row['notes']) ?>" maxlength="255"></label>
  </div>
  <button class="btn" type="submit">Save customer</button> <a class="btn btn-outline" href="customers.php">Cancel</a>
</form>
<?php endif; ?>
<form method="get" class="filters panel"><input type="text" name="q" placeholder="Search by name, email or phone" value="<?= e($q) ?>"><button class="btn" type="submit">Search</button></form>
<div class="table-wrap"><table class="table">
  <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Account</th><th>Bookings</th><th>Total spent</th><th>Notes</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= e($r['full_name']) ?></td><td><?= e($r['email']) ?></td><td><?= e($r['phone']) ?></td>
      <td><?= $r['user_id'] ? 'Online' : 'Walk-in' ?></td><td><?= (int)$r['visits'] ?></td><td><?= money($r['spent']) ?></td>
      <td class="muted"><?= e($r['notes']) ?></td>
      <td class="actions">
        <a class="btn btn-small btn-outline" href="customers.php?edit=<?= (int)$r['customer_id'] ?>">Edit</a>
        <form method="post" class="inline js-confirm" data-confirm="Delete <?= e($r['full_name']) ?> and all of their bookings?">
          <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="customer_id" value="<?= (int)$r['customer_id'] ?>">
          <button class="btn btn-small btn-danger" type="submit">Delete</button></form>
      </td>
    </tr>
  <?php endforeach; if (!$rows): ?><tr><td colspan="8" class="center muted">No customers found.</td></tr><?php endif; ?>
  </tbody>
</table></div>
<?php $extraJs = 'forms.js'; require '../includes/footer.php'; ?>
