<?php
$pageTitle = 'Reports';
require_once '../includes/functions.php';
require_admin();
$pdo = db();
$from = $_GET['from'] ?? '2026-09-01';
$to = $_GET['to'] ?? date('Y-m-t');
if (!valid_date($from) || !valid_date($to) || $from > $to) {
    flash('error', 'Invalid date range - showing the default period instead.');
    $from = '2026-09-01'; $to = date('Y-m-t');
}
$p = [$from, $to];
$billable = "a.status IN ('confirmed','completed') AND a.appt_date BETWEEN ? AND ?";

function q(PDO $pdo, string $sql, array $p): array { $st = $pdo->prepare($sql); $st->execute($p); return $st->fetchAll(); }

$byCategory = q($pdo, "SELECT c.name AS label, COUNT(*) AS bookings, SUM(a.price_charged) AS revenue
    FROM appointments a JOIN services s ON s.service_id=a.service_id JOIN service_categories c ON c.category_id=s.category_id
    WHERE $billable GROUP BY c.category_id ORDER BY revenue DESC", $p);
$byStaff = q($pdo, "SELECT st.full_name AS label, COUNT(*) AS bookings, SUM(a.price_charged) AS revenue
    FROM appointments a JOIN staff st ON st.staff_id=a.staff_id WHERE $billable GROUP BY st.staff_id ORDER BY revenue DESC", $p);
$byStatus = q($pdo, "SELECT status AS label, COUNT(*) AS bookings, SUM(price_charged) AS revenue FROM appointments a
    WHERE a.appt_date BETWEEN ? AND ? GROUP BY status", $p);
$topServices = q($pdo, "SELECT s.name AS label, COUNT(*) AS bookings, SUM(a.price_charged) AS revenue
    FROM appointments a JOIN services s ON s.service_id=a.service_id WHERE $billable GROUP BY s.service_id ORDER BY bookings DESC, revenue DESC LIMIT 5", $p);
$topCustomers = q($pdo, "SELECT c.full_name AS label, COUNT(*) AS bookings, SUM(a.price_charged) AS revenue
    FROM appointments a JOIN customers c ON c.customer_id=a.customer_id WHERE $billable GROUP BY c.customer_id ORDER BY revenue DESC LIMIT 5", $p);
$total = q($pdo, "SELECT COUNT(*) AS n, COALESCE(SUM(price_charged),0) AS rev FROM appointments a WHERE $billable", $p)[0];

// CSV export of the detailed report
if (isset($_GET['export'])) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="glowwell_report_' . $from . '_to_' . $to . '.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Date', 'Customer', 'Service', 'Therapist', 'Status', 'Price']);
    foreach (q($pdo, "SELECT a.appt_date, c.full_name, s.name, st.full_name AS t, a.status, a.price_charged FROM appointments a
        JOIN customers c ON c.customer_id=a.customer_id JOIN services s ON s.service_id=a.service_id JOIN staff st ON st.staff_id=a.staff_id
        WHERE a.appt_date BETWEEN ? AND ? ORDER BY a.appt_date", $p) as $r) fputcsv($out, array_values($r));
    exit;
}
function report_table(string $title, array $rows, string $col): void { ?>
  <div class="panel"><h3><?= e($title) ?></h3>
  <table class="table"><thead><tr><th><?= e($col) ?></th><th>Bookings</th><th>Revenue</th></tr></thead><tbody>
  <?php foreach ($rows as $r): ?><tr><td><?= e(ucfirst($r['label'])) ?></td><td><?= (int)$r['bookings'] ?></td><td><?= money($r['revenue']) ?></td></tr>
  <?php endforeach; if (!$rows): ?><tr><td colspan="3" class="muted center">No data</td></tr><?php endif; ?></tbody></table></div>
<?php }
require '../includes/header.php';
?>
<div class="page-head"><h2>Reports</h2>
  <div><button class="btn btn-outline" type="button" onclick="window.print()">Print</button>
  <a class="btn" href="reports.php?from=<?= e($from) ?>&amp;to=<?= e($to) ?>&amp;export=1">Export CSV</a></div></div>
<form method="get" class="filters panel">
  <label class="inline-label">From <input type="date" name="from" value="<?= e($from) ?>"></label>
  <label class="inline-label">To <input type="date" name="to" value="<?= e($to) ?>"></label>
  <button class="btn" type="submit">Generate report</button>
</form>
<div class="stat-grid">
  <div class="stat"><div class="stat-num"><?= (int)$total['n'] ?></div><div class="muted">Confirmed / completed bookings</div></div>
  <div class="stat stat-accent"><div class="stat-num"><?= money($total['rev']) ?></div><div>Revenue in period</div></div>
  <div class="stat"><div class="stat-num"><?= $total['n'] ? money($total['rev'] / $total['n']) : money(0) ?></div><div class="muted">Average booking value</div></div>
</div>
<div class="panel"><h3>Revenue by category</h3><canvas id="barChart" width="760" height="260" data-chart='<?= e(json_encode(array_map(fn($r) => ['label' => $r['label'], 'value' => (float)$r['revenue']], $byCategory))) ?>' data-money="1"></canvas></div>
<div class="grid-2 top">
  <?php report_table('Revenue by category', $byCategory, 'Category'); report_table('Revenue by therapist', $byStaff, 'Therapist');
        report_table('Top 5 services', $topServices, 'Service'); report_table('Top 5 customers', $topCustomers, 'Customer');
        report_table('Bookings by status (all)', $byStatus, 'Status'); ?>
</div>
<?php $extraJs = 'chart.js'; require '../includes/footer.php'; ?>
