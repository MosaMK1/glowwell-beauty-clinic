<?php
$pageTitle = 'Staff';
require_once '../includes/functions.php';
require_admin();
$pdo = db();
$errors = [];
$editId = (int)($_GET['edit'] ?? $_POST['staff_id'] ?? 0);
$showForm = isset($_GET['add']) || $editId;
$row = ['full_name' => '', 'email' => '', 'phone' => '', 'job_title' => '', 'is_active' => 1];
$mySvc = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (post('action') === 'delete') {
        $st = $pdo->prepare('SELECT COUNT(*) FROM appointments WHERE staff_id = ?');
        $st->execute([(int)post('staff_id')]);
        if ($st->fetchColumn() > 0) {
            flash('error', 'This staff member has bookings and cannot be deleted. Mark them as inactive instead.');
        } else {
            $pdo->prepare('DELETE FROM staff WHERE staff_id = ?')->execute([(int)post('staff_id')]);
            flash('success', 'Staff member deleted.');
        }
        redirect('staff.php');
    }
    $row = ['full_name' => post('full_name'), 'email' => post('email'), 'phone' => post('phone'), 'job_title' => post('job_title'), 'is_active' => isset($_POST['is_active']) ? 1 : 0];
    $mySvc = array_filter(array_map('intval', $_POST['services'] ?? []));
    if (empty($row['full_name'])) $errors[] = 'Full name is required.';
    if (!filter_var($row['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'A valid email is required.';
    if (!valid_phone($row['phone'])) $errors[] = 'Phone must be 10 digits starting with 0.';
    if (empty($row['job_title'])) $errors[] = 'Job title is required.';
    if (!$errors) {
        $st = $pdo->prepare('SELECT 1 FROM staff WHERE email = ? AND staff_id <> ?');
        $st->execute([$row['email'], $editId]);
        if ($st->fetch()) $errors[] = 'Another staff member already uses that email.';
    }
    if (!$errors) {
        $pdo->beginTransaction();
        if ($editId) {
            $pdo->prepare('UPDATE staff SET full_name=?, email=?, phone=?, job_title=?, is_active=? WHERE staff_id=?')
                ->execute([$row['full_name'], $row['email'], $row['phone'], $row['job_title'], $row['is_active'], $editId]);
            $sid = $editId;
        } else {
            $pdo->prepare('INSERT INTO staff (full_name,email,phone,job_title,is_active) VALUES (?,?,?,?,?)')
                ->execute([$row['full_name'], $row['email'], $row['phone'], $row['job_title'], $row['is_active']]);
            $sid = (int)$pdo->lastInsertId();
            // New staff get a default Mon-Fri 09:00-17:00 schedule
            $pdo->prepare("INSERT INTO staff_schedules (staff_id,day_of_week,start_time,end_time) SELECT ?, d, '09:00','17:00' FROM (SELECT 1 d UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5) x")->execute([$sid]);
        }
        $pdo->prepare('DELETE FROM staff_services WHERE staff_id = ?')->execute([$sid]);
        $ins = $pdo->prepare('INSERT INTO staff_services (staff_id, service_id) VALUES (?,?)');
        foreach ($mySvc as $svc) $ins->execute([$sid, $svc]);
        $pdo->commit();
        flash('success', $editId ? 'Staff member updated.' : 'Staff member added with a default weekday schedule.');
        redirect('staff.php');
    }
    $showForm = true;
} elseif ($editId) {
    $st = $pdo->prepare('SELECT * FROM staff WHERE staff_id = ?');
    $st->execute([$editId]);
    $row = $st->fetch();
    if (!$row) { flash('error', 'Staff member not found.'); redirect('staff.php'); }
    $st = $pdo->prepare('SELECT service_id FROM staff_services WHERE staff_id = ?');
    $st->execute([$editId]);
    $mySvc = $st->fetchAll(PDO::FETCH_COLUMN);
}
$allSvc = $pdo->query('SELECT service_id, name FROM services ORDER BY name')->fetchAll();
$rows = $pdo->query(
    "SELECT st.*, GROUP_CONCAT(s.name ORDER BY s.name SEPARATOR ', ') AS services
     FROM staff st LEFT JOIN staff_services ss ON ss.staff_id=st.staff_id LEFT JOIN services s ON s.service_id=ss.service_id
     GROUP BY st.staff_id ORDER BY st.full_name"
)->fetchAll();
require '../includes/header.php';
?>
<div class="page-head"><h2>Staff</h2><a class="btn" href="staff.php?add=1">+ Add staff member</a></div>
<?php if ($showForm): ?>
<form method="post" class="panel js-validate" novalidate>
  <h3><?= $editId ? 'Edit staff member' : 'Add staff member' ?></h3>
  <?php foreach ($errors as $er): ?><div class="alert alert-error"><?= e($er) ?></div><?php endforeach; ?>
  <?= csrf_field() ?><input type="hidden" name="staff_id" value="<?= $editId ?>">
  <div class="grid-2">
    <label>Full name<input type="text" name="full_name" value="<?= e($row['full_name']) ?>" required></label>
    <label>Job title<input type="text" name="job_title" value="<?= e($row['job_title']) ?>" required></label>
    <label>Email<input type="email" name="email" value="<?= e($row['email']) ?>" required></label>
    <label>Phone<input type="text" name="phone" value="<?= e($row['phone']) ?>" required pattern="0\d{9}" data-msg="Phone must be 10 digits starting with 0"></label>
  </div>
  <label class="block-label">Services this person can perform</label>
  <div class="checks"><?php foreach ($allSvc as $s): ?>
    <label class="check"><input type="checkbox" name="services[]" value="<?= (int)$s['service_id'] ?>" <?= in_array((int)$s['service_id'], array_map('intval', $mySvc), true) ? 'checked' : '' ?>> <?= e($s['name']) ?></label>
  <?php endforeach; ?></div>
  <label class="check"><input type="checkbox" name="is_active" <?= $row['is_active'] ? 'checked' : '' ?>> Active (can be booked)</label>
  <button class="btn" type="submit">Save staff member</button> <a class="btn btn-outline" href="staff.php">Cancel</a>
</form>
<?php endif; ?>
<div class="table-wrap"><table class="table">
  <thead><tr><th>Name</th><th>Title</th><th>Contact</th><th>Services</th><th>Status</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= e($r['full_name']) ?></td><td><?= e($r['job_title']) ?></td>
      <td><?= e($r['email']) ?><br><span class="muted"><?= e($r['phone']) ?></span></td>
      <td class="muted small"><?= e($r['services']) ?></td>
      <td><span class="badge <?= $r['is_active'] ? 'badge-confirmed' : 'badge-cancelled' ?>"><?= $r['is_active'] ? 'Active' : 'Inactive' ?></span></td>
      <td class="actions">
        <a class="btn btn-small btn-outline" href="staff.php?edit=<?= (int)$r['staff_id'] ?>">Edit</a>
        <form method="post" class="inline js-confirm" data-confirm="Delete <?= e($r['full_name']) ?>?">
          <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="staff_id" value="<?= (int)$r['staff_id'] ?>">
          <button class="btn btn-small btn-danger" type="submit">Delete</button></form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<?php $extraJs = 'forms.js'; require '../includes/footer.php'; ?>
