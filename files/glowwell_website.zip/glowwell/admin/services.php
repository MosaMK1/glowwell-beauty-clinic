<?php
$pageTitle = 'Services';
require_once '../includes/functions.php';
require_admin();
$pdo = db();
$errors = [];
$editId = (int)($_GET['edit'] ?? $_POST['service_id'] ?? 0);
$showForm = isset($_GET['add']) || $editId;
$row = ['category_id' => '', 'name' => '', 'description' => '', 'duration_min' => '', 'price' => '', 'is_active' => 1];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (post('action') === 'delete') {
        $st = $pdo->prepare('SELECT COUNT(*) FROM appointments WHERE service_id = ?');
        $st->execute([(int)post('service_id')]);
        if ($st->fetchColumn() > 0) {
            flash('error', 'This service has bookings and cannot be deleted. Untick "Active" to hide it instead.');
        } else {
            $pdo->prepare('DELETE FROM services WHERE service_id = ?')->execute([(int)post('service_id')]);
            flash('success', 'Service deleted.');
        }
        redirect('services.php');
    }
    $row = ['category_id' => post('category_id'), 'name' => post('name'), 'description' => post('description'), 'duration_min' => post('duration_min'), 'price' => post('price'), 'is_active' => isset($_POST['is_active']) ? 1 : 0];
    if (empty($row['category_id']) || !is_numeric($row['category_id'])) $errors[] = 'Please choose a category.';
    if (empty($row['name'])) $errors[] = 'Service name is required.';
    if (!is_numeric($row['duration_min']) || $row['duration_min'] < 15 || $row['duration_min'] > 240) $errors[] = 'Duration must be a number between 15 and 240 minutes.';
    if (!is_numeric($row['price']) || $row['price'] <= 0) $errors[] = 'Price must be a number greater than zero.';
    if (!$errors) {
        $st = $pdo->prepare('SELECT 1 FROM services WHERE name = ? AND service_id <> ?');
        $st->execute([$row['name'], $editId]);
        if ($st->fetch()) $errors[] = 'A service with that name already exists.';
    }
    if (!$errors) {
        $args = [(int)$row['category_id'], $row['name'], $row['description'] ?: null, (int)$row['duration_min'], (float)$row['price'], $row['is_active']];
        if ($editId) {
            $pdo->prepare('UPDATE services SET category_id=?, name=?, description=?, duration_min=?, price=?, is_active=? WHERE service_id=?')->execute([...$args, $editId]);
            flash('success', 'Service updated.');
        } else {
            $pdo->prepare('INSERT INTO services (category_id,name,description,duration_min,price,is_active) VALUES (?,?,?,?,?,?)')->execute($args);
            flash('success', 'Service added.');
        }
        redirect('services.php');
    }
    $showForm = true;
} elseif ($editId) {
    $st = $pdo->prepare('SELECT * FROM services WHERE service_id = ?');
    $st->execute([$editId]);
    $row = $st->fetch();
    if (!$row) { flash('error', 'Service not found.'); redirect('services.php'); }
}
$cats = $pdo->query('SELECT * FROM service_categories ORDER BY name')->fetchAll();
$rows = $pdo->query('SELECT s.*, c.name AS cat FROM services s JOIN service_categories c ON c.category_id=s.category_id ORDER BY c.name, s.name')->fetchAll();
require '../includes/header.php';
?>
<div class="page-head"><h2>Services</h2><a class="btn" href="services.php?add=1">+ Add service</a></div>
<?php if ($showForm): ?>
<form method="post" class="panel js-validate" novalidate>
  <h3><?= $editId ? 'Edit service' : 'Add service' ?></h3>
  <?php foreach ($errors as $er): ?><div class="alert alert-error"><?= e($er) ?></div><?php endforeach; ?>
  <?= csrf_field() ?><input type="hidden" name="service_id" value="<?= $editId ?>">
  <div class="grid-2">
    <label>Category<select name="category_id" required><option value="">-- Select --</option>
      <?php foreach ($cats as $c): ?><option value="<?= (int)$c['category_id'] ?>" <?= (int)$row['category_id'] === (int)$c['category_id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></label>
    <label>Name<input type="text" name="name" value="<?= e($row['name']) ?>" required></label>
    <label>Duration (minutes)<input type="number" name="duration_min" value="<?= e($row['duration_min']) ?>" min="15" max="240" step="5" required></label>
    <label>Price (Rand)<input type="number" name="price" value="<?= e($row['price']) ?>" min="1" step="0.01" required></label>
  </div>
  <label>Description<input type="text" name="description" value="<?= e($row['description']) ?>" maxlength="255"></label>
  <label class="check"><input type="checkbox" name="is_active" <?= $row['is_active'] ? 'checked' : '' ?>> Active (visible to customers)</label>
  <button class="btn" type="submit">Save service</button> <a class="btn btn-outline" href="services.php">Cancel</a>
</form>
<?php endif; ?>
<div class="table-wrap"><table class="table">
  <thead><tr><th>Category</th><th>Service</th><th>Duration</th><th>Price</th><th>Status</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= e($r['cat']) ?></td><td><?= e($r['name']) ?><br><span class="muted small"><?= e($r['description']) ?></span></td>
      <td><?= (int)$r['duration_min'] ?> min</td><td><?= money($r['price']) ?></td>
      <td><span class="badge <?= $r['is_active'] ? 'badge-confirmed' : 'badge-cancelled' ?>"><?= $r['is_active'] ? 'Active' : 'Hidden' ?></span></td>
      <td class="actions">
        <a class="btn btn-small btn-outline" href="services.php?edit=<?= (int)$r['service_id'] ?>">Edit</a>
        <form method="post" class="inline js-confirm" data-confirm="Delete <?= e($r['name']) ?>?">
          <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="service_id" value="<?= (int)$r['service_id'] ?>">
          <button class="btn btn-small btn-danger" type="submit">Delete</button></form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<?php $extraJs = 'forms.js'; require '../includes/footer.php'; ?>
