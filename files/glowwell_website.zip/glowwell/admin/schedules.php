<?php
$pageTitle = 'Staff schedules';
require_once '../includes/functions.php';
require_admin();
$pdo = db();
$days = [1 => 'Mon', 2 => 'Tue', 3 => 'Wed', 4 => 'Thu', 5 => 'Fri', 6 => 'Sat', 7 => 'Sun'];

// Save one staff member's weekly schedule (replace-all inside a transaction)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $sid = post('staff_id');
    $errors = [];
    $new = [];
    if (empty($sid) || !is_numeric($sid)) $errors[] = 'Invalid staff member.';
    foreach ($days as $n => $label) {
        if (isset($_POST['work'][$n])) {
            $s = $_POST['start'][$n] ?? ''; $e = $_POST['end'][$n] ?? '';
            if (!valid_time($s) || !valid_time($e)) $errors[] = "$label: please enter valid start and end times.";
            elseif ($s >= $e) $errors[] = "$label: the end time must be after the start time.";
            else $new[$n] = [$s, $e];
        }
    }
    if ($errors) {
        foreach ($errors as $er) flash('error', $er);
    } else {
        $pdo->beginTransaction();
        $pdo->prepare('DELETE FROM staff_schedules WHERE staff_id = ?')->execute([(int)$sid]);
        $ins = $pdo->prepare('INSERT INTO staff_schedules (staff_id, day_of_week, start_time, end_time) VALUES (?,?,?,?)');
        foreach ($new as $n => [$s, $e]) $ins->execute([(int)$sid, $n, $s, $e]);
        $pdo->commit();
        flash('success', 'Schedule saved.');
    }
    redirect('schedules.php');
}
$staff = $pdo->query('SELECT staff_id, full_name, job_title FROM staff WHERE is_active = 1 ORDER BY full_name')->fetchAll();
$sch = [];
foreach ($pdo->query('SELECT * FROM staff_schedules')->fetchAll() as $r) {
    $sch[$r['staff_id']][$r['day_of_week']] = $r;
}
require '../includes/header.php';
?>
<div class="page-head"><h2>Staff schedules</h2></div>
<p class="muted">Tick the days each person works and set their hours. Customers can only book inside these hours.</p>
<?php foreach ($staff as $s): ?>
<form method="post" class="panel">
  <?= csrf_field() ?><input type="hidden" name="staff_id" value="<?= (int)$s['staff_id'] ?>">
  <h3><?= e($s['full_name']) ?> <span class="muted small">&ndash; <?= e($s['job_title']) ?></span></h3>
  <div class="week">
    <?php foreach ($days as $n => $label): $d = $sch[$s['staff_id']][$n] ?? null; ?>
      <div class="day <?= $d ? 'on' : '' ?>">
        <label class="check"><input type="checkbox" class="work-toggle" name="work[<?= $n ?>]" <?= $d ? 'checked' : '' ?>> <strong><?= $label ?></strong></label>
        <input type="time" name="start[<?= $n ?>]" value="<?= e($d ? substr($d['start_time'], 0, 5) : '09:00') ?>">
        <input type="time" name="end[<?= $n ?>]" value="<?= e($d ? substr($d['end_time'], 0, 5) : '17:00') ?>">
      </div>
    <?php endforeach; ?>
  </div>
  <button class="btn btn-small" type="submit">Save schedule</button>
</form>
<?php endforeach; ?>
<?php $extraJs = 'forms.js'; require '../includes/footer.php'; ?>
