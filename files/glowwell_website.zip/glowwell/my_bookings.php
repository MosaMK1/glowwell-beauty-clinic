<?php
$pageTitle = 'My bookings';
require_once 'includes/functions.php';
require_login();
if (is_admin()) redirect('admin/bookings.php');
$cid = current_customer_id();
$pdo = db();

// Cancel (soft delete) a booking - POST only, ownership checked in the query
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = post('appointment_id');
    if (empty($id) || !is_numeric($id)) {
        flash('error', 'Invalid booking.');
    } else {
        $st = $pdo->prepare("UPDATE appointments SET status='cancelled' WHERE appointment_id=? AND customer_id=? AND status IN ('pending','confirmed')");
        $st->execute([(int)$id, $cid]);
        if ($st->rowCount()) {
            notify($cid, (int)$id, 'Booking cancelled', "Your booking #$id has been cancelled.");
            flash('success', 'Your booking was cancelled.');
        } else {
            flash('error', 'That booking could not be cancelled.');
        }
    }
    redirect('my_bookings.php');
}

$st = $pdo->prepare(
    'SELECT a.*, s.name AS service, st.full_name AS therapist
     FROM appointments a JOIN services s ON s.service_id = a.service_id JOIN staff st ON st.staff_id = a.staff_id
     WHERE a.customer_id = ? ORDER BY a.appt_date DESC, a.start_time DESC'
);
$st->execute([$cid]);
$rows = $st->fetchAll();
require 'includes/header.php';
?>
<div class="page-head"><h2>My bookings</h2><a class="btn" href="book.php">+ New booking</a></div>
<?php if (!$rows): ?>
  <div class="panel center"><p>You have no bookings yet.</p><a class="btn" href="book.php">Book your first treatment</a></div>
<?php else: ?>
<div class="table-wrap"><table class="table">
  <thead><tr><th>#</th><th>Date</th><th>Time</th><th>Service</th><th>Therapist</th><th>Price</th><th>Status</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= (int)$r['appointment_id'] ?></td>
      <td><?= e(date('D, d M Y', strtotime($r['appt_date']))) ?></td>
      <td><?= e(substr($r['start_time'], 0, 5)) ?> - <?= e(substr($r['end_time'], 0, 5)) ?></td>
      <td><?= e($r['service']) ?></td>
      <td><?= e($r['therapist']) ?></td>
      <td><?= money($r['price_charged']) ?></td>
      <td><span class="badge badge-<?= e($r['status']) ?>"><?= e(ucfirst($r['status'])) ?></span></td>
      <td class="actions">
        <?php if (in_array($r['status'], ['pending', 'confirmed'], true) && $r['appt_date'] >= date('Y-m-d')): ?>
          <a class="btn btn-small btn-outline" href="book.php?reschedule=<?= (int)$r['appointment_id'] ?>">Reschedule</a>
          <form method="post" class="inline js-confirm" data-confirm="Cancel this booking?">
            <?= csrf_field() ?><input type="hidden" name="appointment_id" value="<?= (int)$r['appointment_id'] ?>">
            <button class="btn btn-small btn-danger" type="submit">Cancel</button>
          </form>
        <?php else: ?>&mdash;<?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<?php endif; ?>
<?php $extraJs = 'forms.js'; require 'includes/footer.php'; ?>
