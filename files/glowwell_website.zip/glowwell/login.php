<?php
$pageTitle = 'Login';
require_once 'includes/functions.php';
$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $email = post('email');
    $pass = $_POST['password'] ?? '';
    if (empty($email) || empty($pass)) {
        $error = 'Please enter both your email and password.';
    } else {
        $st = db()->prepare('SELECT user_id, full_name, email, password_hash, role FROM users WHERE email = ?');
        $st->execute([$email]);
        $u = $st->fetch();
        if ($u && password_verify($pass, $u['password_hash'])) {
            session_regenerate_id(true); // prevents session fixation
            unset($u['password_hash']);
            $_SESSION['user'] = $u;
            redirect($u['role'] === 'admin' ? 'admin/dashboard.php' : 'my_bookings.php');
        }
        $error = 'Incorrect email or password.';
    }
}
require 'includes/header.php';
?>
<div class="form-box">
  <h2>Welcome back</h2>
  <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
  <form method="post" class="js-validate" novalidate>
    <?= csrf_field() ?>
    <label>Email<input type="email" name="email" value="<?= e($email) ?>" required></label>
    <label>Password<input type="password" name="password" required></label>
    <button class="btn btn-block" type="submit">Log in</button>
  </form>
  <p class="muted center">New here? <a href="register.php">Create an account</a></p>
</div>
<?php $extraJs = 'forms.js'; require 'includes/footer.php'; ?>
