<?php
/**
 * JSON API: GET ?service_id=1&date=2026-10-12
 * Returns every qualified staff member with their free time slots.
 * Used by book.php (JavaScript fetch) to update the page without reloading.
 */
require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json');

$serviceId = $_GET['service_id'] ?? '';
$date = $_GET['date'] ?? '';
$ignore = (int)($_GET['ignore'] ?? 0);

if (empty($serviceId) || !is_numeric($serviceId) || !valid_date($date)) {
    http_response_code(400);
    echo json_encode(['error' => 'Please choose a service and a valid date.']);
    exit;
}
if ($date < date('Y-m-d')) {
    http_response_code(400);
    echo json_encode(['error' => 'You cannot book a date in the past.']);
    exit;
}

$st = db()->prepare('SELECT duration_min FROM services WHERE service_id = ? AND is_active = 1');
$st->execute([(int)$serviceId]);
$duration = $st->fetchColumn();
if (!$duration) {
    http_response_code(404);
    echo json_encode(['error' => 'That service could not be found.']);
    exit;
}

$st = db()->prepare(
    'SELECT st.staff_id, st.full_name, st.job_title FROM staff st
     JOIN staff_services ss ON ss.staff_id = st.staff_id
     WHERE ss.service_id = ? AND st.is_active = 1 ORDER BY st.full_name'
);
$st->execute([(int)$serviceId]);
$out = [];
foreach ($st->fetchAll() as $s) {
    $out[] = [
        'staff_id' => (int)$s['staff_id'],
        'name'     => $s['full_name'],
        'title'    => $s['job_title'],
        'slots'    => available_slots((int)$s['staff_id'], (int)$duration, $date, $ignore),
    ];
}
echo json_encode(['duration' => (int)$duration, 'staff' => $out]);
